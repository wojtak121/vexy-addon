package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.Entity;

/** Wypisuje na czacie podstawowe informacje debugowe co X sekund. */
public class VexyDebug extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
        .name("interval-seconds")
        .description("Co ile sekund wypisywac info.")
        .defaultValue(5).min(1).sliderMax(60).build());

    private final Setting<Boolean> position = sgGeneral.add(new BoolSetting.Builder()
        .name("position").defaultValue(true).build());
    private final Setting<Boolean> performance = sgGeneral.add(new BoolSetting.Builder()
        .name("fps-ping").defaultValue(true).build());
    private final Setting<Boolean> world = sgGeneral.add(new BoolSetting.Builder()
        .name("world-info").description("Wymiar, liczba encji.").defaultValue(true).build());

    private int timer;

    public VexyDebug() {
        super(VexyAddon.CATEGORY, "vexy-debug", "Informacje debugowe na czacie.");
    }

    @Override
    public void onActivate() {
        timer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (timer++ < interval.get() * 20) return;
        timer = 0;

        if (position.get()) {
            info("Pos: %.1f %.1f %.1f | Yaw %.1f Pitch %.1f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                mc.player.getYRot(), mc.player.getXRot());
        }

        if (performance.get()) {
            PlayerInfo entry = mc.getConnection() != null
                ? mc.getConnection().getPlayerInfo(mc.player.getUUID()) : null;
            info("FPS: %d | Ping: %s", mc.getFps(), entry != null ? entry.getLatency() + "ms" : "?");
        }

        if (world.get()) {
            int entities = 0;
            for (Entity ignored : mc.level.entitiesForRendering()) entities++;
            info("Wymiar: %s | Encje: %d", PlayerUtils.getDimension(), entities);
        }
    }
}
