package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;

/** Wysyla wybrana komende / wiadomosc co X sekund. */
public class VexyAutoCommand extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<String> command = sgGeneral.add(new StringSetting.Builder()
        .name("command").description("Komenda lub wiadomosc, np. /sell all")
        .defaultValue("/help").build());

    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
        .name("interval-seconds").description("Odstep miedzy wyslaniami.")
        .defaultValue(30).min(1).sliderMax(600).build());

    private final Setting<Boolean> sendOnEnable = sgGeneral.add(new BoolSetting.Builder()
        .name("send-on-enable").description("Wyslij od razu po wlaczeniu.").defaultValue(false).build());

    private int timer;

    public VexyAutoCommand() {
        super(VexyAddon.CATEGORY, "vexy-auto-command", "Cyklicznie wysyla komende.");
    }

    @Override
    public void onActivate() {
        timer = 0;
        if (sendOnEnable.get() && mc.player != null) send();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.level == null) return;
        if (timer++ < interval.get() * 20) return;
        timer = 0;
        send();
    }

    private void send() {
        String msg = command.get().trim();
        if (!msg.isEmpty()) ChatUtils.sendPlayerMsg(msg);
    }
}
