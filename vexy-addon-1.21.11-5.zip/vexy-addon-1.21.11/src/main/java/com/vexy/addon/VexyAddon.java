package com.vexy.addon;

import com.vexy.addon.modules.*;
import com.mojang.logging.LogUtils;
import meteordevelopment.meteorclient.addons.GithubRepo;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

public class VexyAddon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();
    public static final Category CATEGORY = new Category("Vexy");

    @Override
    public void onInitialize() {
        LOG.info("Initializing Vexy Addon");

        Modules.get().add(new VexyChunkFinder());
        Modules.get().add(new VexyDebug());
        Modules.get().add(new VexySpawnerNotifier());
        Modules.get().add(new VexyEsp());
        Modules.get().add(new VexyStorageEsp());
        Modules.get().add(new VexyPlayerAlert());
        Modules.get().add(new VexyAutoCommand());
        Modules.get().add(new VexyAutoTotem());
        Modules.get().add(new VexyRainNotifier());
        Modules.get().add(new VexyCoordSnapper());
        Modules.get().add(new VexyTabDetector());
        Modules.get().add(new VexyChestStealer());
        Modules.get().add(new VexyBlockEsp());
        Modules.get().add(new VexyHoleEsp());
        Modules.get().add(new VexyDeathCoords());
        Modules.get().add(new VexyItemDropper());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.vexy.addon";
    }

    @Override
    public GithubRepo getRepo() {
        return new GithubRepo("TwojNick", "vexy-addon");
    }
}
