package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.HashSet;
import java.util.Set;

/** Powiadamia, gdy w zaladowanych chunkach pojawi sie spawner. */
public class VexySpawnerNotifier extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> chat = sgGeneral.add(new BoolSetting.Builder()
        .name("chat").description("Wiadomosc na czacie.").defaultValue(true).build());

    private final Setting<Boolean> sound = sgGeneral.add(new BoolSetting.Builder()
        .name("sound").description("Dzwiek po znalezieniu spawnera.").defaultValue(true).build());

    private final Setting<Boolean> showEntity = sgGeneral.add(new BoolSetting.Builder()
        .name("show-mob-type").description("Probuje pokazac typ moba w spawnerze.").defaultValue(true).build());

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval").description("Co ile tickow skanowac.")
        .defaultValue(20).min(5).sliderMax(200).build());

    private final Set<BlockPos> notified = new HashSet<>();
    private int timer;

    public VexySpawnerNotifier() {
        super(VexyAddon.CATEGORY, "spawner-notifier", "Powiadamia o znalezionych spawnerach.");
    }

    @Override
    public void onActivate() {
        notified.clear();
        timer = 0;
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        notified.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (timer++ < scanInterval.get()) return;
        timer = 0;

        int r = mc.options.renderDistance().get();
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;

        for (int x = pcx - r; x <= pcx + r; x++) {
            for (int z = pcz - r; z <= pcz + r; z++) {
                ChunkAccess chunk = mc.level.getChunkSource().getChunk(x, z, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                for (BlockPos pos : chunk.getBlockEntitiesPos()) {
                    BlockEntity be = chunk.getBlockEntity(pos);
                    if (!(be instanceof SpawnerBlockEntity spawner)) continue;
                    if (!notified.add(pos.immutable())) continue;

                    if (chat.get()) {
                        String mob = "";
                        if (showEntity.get()) {
                            try {
                                Entity e = spawner.getSpawner().getOrCreateDisplayEntity(mc.level, pos);
                                if (e != null) mob = " (" + e.getType().getDescription().getString() + ")";
                            } catch (Throwable ignored) {
                                // API spawnera zmienia sie miedzy wersjami - brak typu moba nie psuje reszty
                            }
                        }
                        info("Spawner%s: %d %d %d", mob, pos.getX(), pos.getY(), pos.getZ());
                    }
                    if (sound.get()) mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1f);
                }
            }
        }
    }

    @Override
    public String getInfoString() {
        return String.valueOf(notified.size());
    }
}
