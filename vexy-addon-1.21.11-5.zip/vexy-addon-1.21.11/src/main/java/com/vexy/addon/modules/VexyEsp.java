package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.AABB;

import java.util.Set;

/** Prosty ESP boxowy dla wybranych encji. */
public class VexyEsp extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Set<EntityType<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities").description("Encje do podswietlenia.")
        .defaultValue(Set.<EntityType<?>>of(EntityType.PLAYER)).build());

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range").description("Maksymalny dystans.")
        .defaultValue(128).min(8).sliderMax(256).build());

    private final Setting<Boolean> ignoreSelf = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-self").defaultValue(true).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").defaultValue(new SettingColor(255, 0, 100, 40)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").defaultValue(new SettingColor(255, 0, 100, 255)).build());

    public VexyEsp() {
        super(VexyAddon.CATEGORY, "vexy-esp", "ESP dla wybranych encji.");
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.level == null || mc.player == null) return;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (ignoreSelf.get() && entity == mc.player) continue;
            if (!entities.get().contains(entity.getType())) continue;
            if (mc.player.distanceTo(entity) > range.get()) continue;

            double x = Mth.lerp(event.tickDelta, entity.xOld, entity.getX()) - entity.getX();
            double y = Mth.lerp(event.tickDelta, entity.yOld, entity.getY()) - entity.getY();
            double z = Mth.lerp(event.tickDelta, entity.zOld, entity.getZ()) - entity.getZ();

            AABB b = entity.getBoundingBox();
            event.renderer.box(x + b.minX, y + b.minY, z + b.minZ, x + b.maxX, y + b.maxY, z + b.maxZ,
                sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    }
}
