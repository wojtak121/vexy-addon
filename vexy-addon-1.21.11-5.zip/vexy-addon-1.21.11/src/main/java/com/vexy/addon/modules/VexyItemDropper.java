package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/** Wyrzuca z ekwipunku wybrane przedmioty (po jednym stacku co X tickow). */
public class VexyItemDropper extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<Item>> items = sgGeneral.add(new ItemListSetting.Builder()
        .name("items").description("Przedmioty do wyrzucenia.")
        .defaultValue(List.of(Items.COBBLESTONE)).build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay").description("Ticki miedzy wyrzuceniami.")
        .defaultValue(4).min(1).sliderMax(40).build());

    private final Setting<Boolean> hotbar = sgGeneral.add(new BoolSetting.Builder()
        .name("include-hotbar").description("Wyrzucaj tez z hotbaru.").defaultValue(false).build());

    private int timer;

    public VexyItemDropper() {
        super(VexyAddon.CATEGORY, "vexy-item-dropper", "Wyrzuca wybrane przedmioty z ekwipunku.");
    }

    @Override
    public void onActivate() {
        timer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        if (timer > 0) { timer--; return; }

        int start = hotbar.get() ? 0 : 9;
        for (int i = start; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (stack.isEmpty() || !items.get().contains(stack.getItem())) continue;

            InvUtils.drop().slot(i);
            timer = delay.get();
            return;
        }
    }
}
