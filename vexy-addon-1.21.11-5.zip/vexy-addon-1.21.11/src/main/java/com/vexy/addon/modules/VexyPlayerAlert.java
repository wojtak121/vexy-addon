package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Alert, gdy inny gracz pojawi sie w zasiegu renderowania. */
public class VexyPlayerAlert extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> ignoreFriends = sgGeneral.add(new BoolSetting.Builder()
        .name("ignore-friends").defaultValue(true).build());
    private final Setting<Boolean> chat = sgGeneral.add(new BoolSetting.Builder()
        .name("chat").defaultValue(true).build());
    private final Setting<Boolean> sound = sgGeneral.add(new BoolSetting.Builder()
        .name("sound").defaultValue(true).build());
    private final Setting<Boolean> leaveAlert = sgGeneral.add(new BoolSetting.Builder()
        .name("notify-on-leave").description("Info, gdy gracz wyjdzie z zasiegu.").defaultValue(false).build());

    private final Set<UUID> seen = new HashSet<>();

    public VexyPlayerAlert() {
        super(VexyAddon.CATEGORY, "vexy-player-alert", "Powiadamia o graczach w poblizu.");
    }

    @Override
    public void onActivate() {
        seen.clear();
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        seen.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;

        Set<UUID> now = new HashSet<>();
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            if (ignoreFriends.get() && Friends.get().isFriend(p)) continue;

            now.add(p.getUUID());
            if (seen.add(p.getUUID())) {
                if (chat.get()) {
                    info("Gracz w poblizu: %s (%.0f m) @ %d %d %d", p.getName().getString(),
                        mc.player.distanceTo(p), p.getBlockX(), p.getBlockY(), p.getBlockZ());
                }
                if (sound.get()) mc.player.playSound(SoundEvents.NOTE_BLOCK_PLING.value(), 1f, 1f);
            }
        }

        if (leaveAlert.get() && chat.get()) {
            for (UUID id : seen) {
                if (!now.contains(id)) info("Gracz wyszedl z zasiegu.");
            }
        }
        seen.retainAll(now);
    }
}
