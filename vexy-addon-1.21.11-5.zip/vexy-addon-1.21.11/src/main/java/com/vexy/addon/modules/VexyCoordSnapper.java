package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;

/** Kopiuje wspolrzedne do schowka i sam sie wylacza - wygodne pod keybind. */
public class VexyCoordSnapper extends Module {
    public enum Format { Plain, Commas, TpCommand }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Format> format = sgGeneral.add(new EnumSetting.Builder<Format>()
        .name("format").description("Format kopiowanych wspolrzednych.")
        .defaultValue(Format.Plain).build());

    private final Setting<Boolean> sendToChat = sgGeneral.add(new BoolSetting.Builder()
        .name("show-in-chat").description("Pokaz wspolrzedne tez na czacie (tylko u Ciebie).")
        .defaultValue(true).build());

    public VexyCoordSnapper() {
        super(VexyAddon.CATEGORY, "vexy-coord-snapper", "Kopiuje Twoje koordy do schowka.");
    }

    @Override
    public void onActivate() {
        if (mc.player != null) {
            int x = mc.player.getBlockX(), y = mc.player.getBlockY(), z = mc.player.getBlockZ();
            String text = switch (format.get()) {
                case Plain -> x + " " + y + " " + z;
                case Commas -> x + ", " + y + ", " + z;
                case TpCommand -> "/tp @s " + x + " " + y + " " + z;
            };
            mc.keyboardHandler.setClipboard(text);
            if (sendToChat.get()) info("Skopiowano: %s", text);
        }
        toggle();
    }
}
