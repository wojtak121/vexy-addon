package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.HashMap;
import java.util.Map;

/** Podswietla skrzynki, beczki, shulkery i enderchesty w zaladowanych chunkach. */
public class VexyStorageEsp extends Module {
    private enum Kind { CHEST, BARREL, SHULKER, ENDER }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgColors = settings.createGroup("Colors");

    private final Setting<Boolean> chests = sgGeneral.add(new BoolSetting.Builder()
        .name("chests").defaultValue(true).build());
    private final Setting<Boolean> barrels = sgGeneral.add(new BoolSetting.Builder()
        .name("barrels").defaultValue(true).build());
    private final Setting<Boolean> shulkers = sgGeneral.add(new BoolSetting.Builder()
        .name("shulkers").defaultValue(true).build());
    private final Setting<Boolean> enderChests = sgGeneral.add(new BoolSetting.Builder()
        .name("ender-chests").defaultValue(false).build());

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval").description("Co ile tickow odswiezac liste.")
        .defaultValue(20).min(5).sliderMax(200).build());

    private final Setting<ShapeMode> shapeMode = sgColors.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());
    private final Setting<SettingColor> chestColor = sgColors.add(new ColorSetting.Builder()
        .name("chest-color").defaultValue(new SettingColor(255, 160, 0, 255)).build());
    private final Setting<SettingColor> barrelColor = sgColors.add(new ColorSetting.Builder()
        .name("barrel-color").defaultValue(new SettingColor(160, 110, 50, 255)).build());
    private final Setting<SettingColor> shulkerColor = sgColors.add(new ColorSetting.Builder()
        .name("shulker-color").defaultValue(new SettingColor(200, 0, 255, 255)).build());
    private final Setting<SettingColor> enderColor = sgColors.add(new ColorSetting.Builder()
        .name("ender-chest-color").defaultValue(new SettingColor(0, 255, 200, 255)).build());

    private Map<BlockPos, Kind> storages = new HashMap<>();
    private int timer;

    public VexyStorageEsp() {
        super(VexyAddon.CATEGORY, "vexy-storage-esp", "ESP na skrzynki, beczki i shulkery.");
    }

    @Override
    public void onActivate() {
        storages = new HashMap<>();
        timer = 1000; // skan od razu
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (timer++ < scanInterval.get()) return;
        timer = 0;

        Map<BlockPos, Kind> next = new HashMap<>();
        int r = mc.options.renderDistance().get();
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;

        for (int x = pcx - r; x <= pcx + r; x++) {
            for (int z = pcz - r; z <= pcz + r; z++) {
                ChunkAccess chunk = mc.level.getChunkSource().getChunk(x, z, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                for (BlockPos pos : chunk.getBlockEntitiesPos()) {
                    BlockEntity be = chunk.getBlockEntity(pos);
                    Kind kind = null;
                    if (chests.get() && be instanceof ChestBlockEntity) kind = Kind.CHEST;
                    else if (barrels.get() && be instanceof BarrelBlockEntity) kind = Kind.BARREL;
                    else if (shulkers.get() && be instanceof ShulkerBoxBlockEntity) kind = Kind.SHULKER;
                    else if (enderChests.get() && be instanceof EnderChestBlockEntity) kind = Kind.ENDER;
                    if (kind != null) next.put(pos.immutable(), kind);
                }
            }
        }
        storages = next;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (Map.Entry<BlockPos, Kind> e : storages.entrySet()) {
            SettingColor line = switch (e.getValue()) {
                case CHEST -> chestColor.get();
                case BARREL -> barrelColor.get();
                case SHULKER -> shulkerColor.get();
                case ENDER -> enderColor.get();
            };
            Color side = new Color(line.r, line.g, line.b, 40);
            event.renderer.box(e.getKey(), side, line, shapeMode.get(), 0);
        }
    }

    @Override
    public String getInfoString() {
        return String.valueOf(storages.size());
    }
}
