package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.status.ChunkStatus;

import java.util.HashSet;
import java.util.Set;

/** Podswietla chunki z duza liczba block entities (skrzynki, spawnery, piece itp.) - pomaga znajdowac bazy. */
public class VexyChunkFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> minBlockEntities = sgGeneral.add(new IntSetting.Builder()
        .name("min-block-entities")
        .description("Minimalna liczba block entities w chunku, zeby go oznaczyc.")
        .defaultValue(5).min(1).sliderMax(50).build());

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval")
        .description("Co ile tickow skanowac chunki.")
        .defaultValue(40).min(5).sliderMax(200).build());

    private final Setting<Boolean> chat = sgGeneral.add(new BoolSetting.Builder()
        .name("chat-notify")
        .description("Wysyla wiadomosc na czacie o nowo znalezionym chunku.")
        .defaultValue(true).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").defaultValue(new SettingColor(255, 170, 0, 40)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").defaultValue(new SettingColor(255, 170, 0, 255)).build());

    private final Setting<Integer> boxHeight = sgRender.add(new IntSetting.Builder()
        .name("box-height")
        .description("Wysokosc rysowanego boxa nad poziomem gracza.")
        .defaultValue(16).min(1).sliderMax(128).build());

    private final Set<ChunkPos> found = new HashSet<>();
    private int timer;

    public VexyChunkFinder() {
        super(VexyAddon.CATEGORY, "vexy-chunk-finder", "Znajduje chunki z duza iloscia block entities.");
    }

    @Override
    public void onActivate() {
        found.clear();
        timer = 0;
    }

    @Override
    public void onDeactivate() {
        found.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (timer++ < scanInterval.get()) return;
        timer = 0;

        int r = mc.options.renderDistance().get();
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;

        for (int x = pcx - r; x <= pcx + r; x++) {
            for (int z = pcz - r; z <= pcz + r; z++) {
                ChunkAccess chunk = mc.level.getChunkSource().getChunk(x, z, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                ChunkPos pos = new ChunkPos(x, z);
                int count = chunk.getBlockEntitiesPos().size();

                if (count >= minBlockEntities.get()) {
                    if (found.add(pos) && chat.get()) {
                        info("Chunk (%d, %d) -> %d block entities.", x, z, count);
                    }
                } else {
                    found.remove(pos);
                }
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.player == null) return;
        double y1 = mc.player.getY() - 2;
        double y2 = y1 + boxHeight.get();

        for (ChunkPos p : found) {
            event.renderer.box(p.getMinBlockX(), y1, p.getMinBlockZ(), p.getMaxBlockX() + 1, y2, p.getMaxBlockZ() + 1,
                sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    }

    @Override
    public String getInfoString() {
        return String.valueOf(found.size());
    }
}
