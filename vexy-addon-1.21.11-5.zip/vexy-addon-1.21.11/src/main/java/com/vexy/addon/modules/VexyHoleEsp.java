package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Wykrywa pionowe szyby 1x1 (powietrze ze scianami z czterech stron) - czesto slad tuneli / baz. */
public class VexyHoleEsp extends Module {
    private record Hole(int x, int y, int z, int depth) {}

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> minDepth = sgGeneral.add(new IntSetting.Builder()
        .name("min-depth").description("Minimalna glebokosc szybu.")
        .defaultValue(3).min(2).sliderMax(30).build());

    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder()
        .name("horizontal-radius").defaultValue(24).min(4).sliderMax(48).build());

    private final Setting<Integer> vertical = sgGeneral.add(new IntSetting.Builder()
        .name("vertical-radius").defaultValue(24).min(4).sliderMax(64).build());

    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval").defaultValue(40).min(10).sliderMax(200).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());
    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").defaultValue(new SettingColor(0, 255, 120, 40)).build());
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").defaultValue(new SettingColor(0, 255, 120, 255)).build());

    private List<Hole> holes = new ArrayList<>();
    private int timer;

    public VexyHoleEsp() {
        super(VexyAddon.CATEGORY, "vexy-hole-esp", "Podswietla szyby 1x1.");
    }

    @Override
    public void onActivate() {
        holes = new ArrayList<>();
        timer = 1000;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (timer++ < interval.get()) return;
        timer = 0;

        List<Hole> next = new ArrayList<>();
        int px = mc.player.getBlockX(), py = mc.player.getBlockY(), pz = mc.player.getBlockZ();
        int r = radius.get(), v = vertical.get(), min = minDepth.get();
        BlockPos.MutableBlockPos a = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos b = new BlockPos.MutableBlockPos();

        for (int x = px - r; x <= px + r; x++) {
            for (int z = pz - r; z <= pz + r; z++) {
                int run = 0;
                int top = 0;
                for (int y = py + v; y >= py - v; y--) {
                    boolean shaft = isAir(a, x, y, z)
                        && isSolid(b, x + 1, y, z) && isSolid(b, x - 1, y, z)
                        && isSolid(b, x, y, z + 1) && isSolid(b, x, y, z - 1);

                    if (shaft) {
                        if (run == 0) top = y;
                        run++;
                    } else {
                        if (run >= min) next.add(new Hole(x, top - run + 1, z, run));
                        run = 0;
                    }
                }
                if (run >= min) next.add(new Hole(x, top - run + 1, z, run));
            }
        }
        holes = next;
    }

    private boolean isAir(BlockPos.MutableBlockPos m, int x, int y, int z) {
        return mc.level.getBlockState(m.set(x, y, z)).isAir();
    }

    private boolean isSolid(BlockPos.MutableBlockPos m, int x, int y, int z) {
        return !mc.level.getBlockState(m.set(x, y, z)).isAir();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (Hole h : holes) {
            event.renderer.box(h.x(), h.y(), h.z(), h.x() + 1, h.y() + h.depth(), h.z() + 1,
                sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    }

    @Override
    public String getInfoString() {
        return String.valueOf(holes.size());
    }
}
