package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.item.Items;

/** Trzyma totem nieśmiertelności w offhandzie. */
public class VexyAutoTotem extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay").description("Opoznienie (ticki) miedzy przeniesieniami.")
        .defaultValue(2).min(0).sliderMax(20).build());

    private final Setting<Double> healthBelow = sgGeneral.add(new DoubleSetting.Builder()
        .name("only-below-health")
        .description("Zakladaj totem tylko gdy zdrowie jest ponizej tej wartosci (0 = zawsze).")
        .defaultValue(0).min(0).sliderMax(20).build());

    private int timer;

    public VexyAutoTotem() {
        super(VexyAddon.CATEGORY, "vexy-auto-totem", "Automatycznie wklada totem do offhanda.");
    }

    @Override
    public void onActivate() {
        timer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.level == null) return;
        if (timer > 0) { timer--; return; }

        double limit = healthBelow.get();
        if (limit > 0 && mc.player.getHealth() + mc.player.getAbsorptionAmount() >= limit) return;

        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;

        FindItemResult totem = InvUtils.find(Items.TOTEM_OF_UNDYING);
        if (!totem.found() || totem.isOffhand()) return;

        InvUtils.move().from(totem.slot()).toOffhand();
        timer = delay.get();
    }

    @Override
    public String getInfoString() {
        return String.valueOf(InvUtils.find(Items.TOTEM_OF_UNDYING).count());
    }
}
