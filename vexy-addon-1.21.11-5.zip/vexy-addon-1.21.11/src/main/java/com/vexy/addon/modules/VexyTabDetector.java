package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.sounds.SoundEvents;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Obserwuje liste graczy (TAB) i powiadamia, gdy wybrani gracze wchodza / wychodza. */
public class VexyTabDetector extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<String>> watched = sgGeneral.add(new StringListSetting.Builder()
        .name("watch-list").description("Nicki do obserwowania (bez rozrozniania wielkosci liter).")
        .defaultValue(List.of()).build());

    private final Setting<Boolean> anyJoin = sgGeneral.add(new BoolSetting.Builder()
        .name("notify-any-join").description("Powiadamiaj o kazdym graczu, ktory wejdzie.")
        .defaultValue(false).build());

    private final Setting<Boolean> leaves = sgGeneral.add(new BoolSetting.Builder()
        .name("notify-leave").description("Powiadamiaj tez o wyjsciu.").defaultValue(true).build());

    private final Setting<Boolean> sound = sgGeneral.add(new BoolSetting.Builder()
        .name("sound").defaultValue(true).build());

    private Set<String> previous = new HashSet<>();
    private boolean ready;
    private int timer;

    public VexyTabDetector() {
        super(VexyAddon.CATEGORY, "vexy-tab-detector", "Wykrywa wejscia/wyjscia graczy z TAB-a.");
    }

    @Override
    public void onActivate() {
        ready = false;
        previous = new HashSet<>();
        timer = 0;
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        ready = false;
        previous = new HashSet<>();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.getConnection() == null || mc.player == null) return;
        if (timer++ < 10) return;
        timer = 0;

        Set<String> now = new HashSet<>();
        for (PlayerInfo info : mc.getConnection().getOnlinePlayers()) {
            now.add(info.getProfile().name());
        }

        if (ready) {
            Set<String> watchLower = new HashSet<>();
            for (String s : watched.get()) watchLower.add(s.toLowerCase(Locale.ROOT));

            for (String n : now) {
                if (previous.contains(n)) continue;
                if (anyJoin.get() || watchLower.contains(n.toLowerCase(Locale.ROOT))) {
                    info("%s wszedl na serwer.", n);
                    if (sound.get()) mc.player.playSound(SoundEvents.NOTE_BLOCK_PLING.value(), 1f, 1f);
                }
            }
            if (leaves.get()) {
                for (String n : previous) {
                    if (now.contains(n)) continue;
                    if (anyJoin.get() || watchLower.contains(n.toLowerCase(Locale.ROOT))) {
                        info("%s wyszedl z serwera.", n);
                    }
                }
            }
        }

        previous = now;
        ready = true;
    }
}
