package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;

/** Po smierci wypisuje na czacie wspolrzedne i wymiar (opcjonalnie kopiuje do schowka). */
public class VexyDeathCoords extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> copy = sgGeneral.add(new BoolSetting.Builder()
        .name("copy-to-clipboard").description("Kopiuj koordy do schowka.").defaultValue(true).build());

    private boolean wasDead;

    public VexyDeathCoords() {
        super(VexyAddon.CATEGORY, "vexy-death-coords", "Zapisuje miejsce Twojej smierci.");
    }

    @Override
    public void onActivate() {
        wasDead = false;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.level == null) return;

        boolean dead = mc.player.isDeadOrDying();
        if (dead && !wasDead) {
            int x = mc.player.getBlockX(), y = mc.player.getBlockY(), z = mc.player.getBlockZ();
            info("Zginales: %d %d %d (%s)", x, y, z, PlayerUtils.getDimension());
            if (copy.get()) mc.keyboardHandler.setClipboard(x + " " + y + " " + z);
        }
        wasDead = dead;
    }
}
