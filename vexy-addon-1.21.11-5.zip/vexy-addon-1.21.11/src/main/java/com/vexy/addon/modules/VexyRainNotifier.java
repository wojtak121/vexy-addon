package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.sounds.SoundEvents;

/** Powiadamia o zmianie pogody (deszcz / burza). */
public class VexyRainNotifier extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> thunder = sgGeneral.add(new BoolSetting.Builder()
        .name("thunder").description("Powiadamiaj tez o burzy.").defaultValue(true).build());
    private final Setting<Boolean> sound = sgGeneral.add(new BoolSetting.Builder()
        .name("sound").defaultValue(true).build());

    private boolean lastRain, lastThunder, ready;

    public VexyRainNotifier() {
        super(VexyAddon.CATEGORY, "vexy-rain-notifier", "Powiadomienie o deszczu i burzy.");
    }

    @Override
    public void onActivate() {
        ready = false;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) { ready = false; return; }

        boolean rain = mc.level.isRaining();
        boolean storm = mc.level.isThundering();

        if (!ready) {
            lastRain = rain;
            lastThunder = storm;
            ready = true;
            return;
        }

        if (rain != lastRain) {
            info(rain ? "Zaczal padac deszcz." : "Deszcz ustal.");
            ping();
        }
        if (thunder.get() && storm != lastThunder) {
            info(storm ? "Burza!" : "Burza minela.");
            ping();
        }
        lastRain = rain;
        lastThunder = storm;
    }

    private void ping() {
        if (sound.get()) mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1f);
    }
}
