package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Uniwersalny ESP na wybrane bloki (dripstone, kelp, ametyst, pistony, winorosla itd.) w promieniu wokol gracza. */
public class VexyBlockEsp extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<List<Block>> blocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks").description("Bloki do podswietlenia.")
        .defaultValue(List.of(Blocks.AMETHYST_BLOCK)).build());

    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder()
        .name("horizontal-radius").description("Promien skanu w poziomie.")
        .defaultValue(32).min(4).sliderMax(64).build());

    private final Setting<Integer> vertical = sgGeneral.add(new IntSetting.Builder()
        .name("vertical-radius").description("Zasieg skanu w pionie.")
        .defaultValue(16).min(2).sliderMax(64).build());

    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval").description("Co ile tickow skanowac.")
        .defaultValue(30).min(5).sliderMax(200).build());

    private final Setting<Integer> maxResults = sgGeneral.add(new IntSetting.Builder()
        .name("max-results").description("Limit podswietlonych blokow (wydajnosc).")
        .defaultValue(1500).min(50).sliderMax(5000).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());
    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").defaultValue(new SettingColor(180, 80, 255, 40)).build());
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").defaultValue(new SettingColor(180, 80, 255, 255)).build());

    private List<BlockPos> found = new ArrayList<>();
    private int timer;

    public VexyBlockEsp() {
        super(VexyAddon.CATEGORY, "vexy-block-esp", "ESP na wybrane bloki w poblizu.");
    }

    @Override
    public void onActivate() {
        found = new ArrayList<>();
        timer = 1000;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (timer++ < interval.get()) return;
        timer = 0;

        Set<Block> wanted = new HashSet<>(blocks.get());
        List<BlockPos> next = new ArrayList<>();
        if (wanted.isEmpty()) { found = next; return; }

        int px = mc.player.getBlockX(), py = mc.player.getBlockY(), pz = mc.player.getBlockZ();
        int r = radius.get(), v = vertical.get(), cap = maxResults.get();
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();

        outer:
        for (int x = px - r; x <= px + r; x++) {
            for (int z = pz - r; z <= pz + r; z++) {
                for (int y = py - v; y <= py + v; y++) {
                    mut.set(x, y, z);
                    if (wanted.contains(mc.level.getBlockState(mut).getBlock())) {
                        next.add(mut.immutable());
                        if (next.size() >= cap) break outer;
                    }
                }
            }
        }
        found = next;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        for (BlockPos pos : found) {
            event.renderer.box(pos, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    }

    @Override
    public String getInfoString() {
        return String.valueOf(found.size());
    }
}
