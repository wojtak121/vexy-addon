package com.vexy.addon.modules;

import com.vexy.addon.VexyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;

/** Po otwarciu skrzynki / beczki / shulkera przenosi z niej wszystkie przedmioty do ekwipunku. */
public class VexyChestStealer extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay").description("Ticki miedzy przeniesieniami (0 = wszystko naraz).")
        .defaultValue(2).min(0).sliderMax(20).build());

    private final Setting<Boolean> autoClose = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-close").description("Zamknij kontener po oproznieniu.").defaultValue(true).build());

    private int timer;
    private boolean fullNotified;

    public VexyChestStealer() {
        super(VexyAddon.CATEGORY, "vexy-chest-stealer", "Szybko oprozznia otwarte kontenery.");
    }

    @Override
    public void onActivate() {
        timer = 0;
        fullNotified = false;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;

        AbstractContainerMenu menu = mc.player.containerMenu;
        if (menu == null || menu == mc.player.inventoryMenu) { fullNotified = false; return; }

        int containerSlots = menu.slots.size() - 36; // 36 = ekwipunek gracza
        if (containerSlots <= 0) return;

        if (timer > 0) { timer--; return; }

        boolean movedAny = false;
        for (int i = 0; i < containerSlots; i++) {
            if (!menu.getSlot(i).hasItem()) continue;

            if (mc.player.getInventory().getFreeSlot() == -1) {
                if (!fullNotified) { info("Ekwipunek pelny."); fullNotified = true; }
                return;
            }

            mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 0, ClickType.QUICK_MOVE, mc.player);
            movedAny = true;

            if (delay.get() > 0) { timer = delay.get(); return; }
        }

        if (!movedAny && autoClose.get()) mc.player.closeContainer();
    }
}
