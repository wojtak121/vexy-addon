# Vexy Addon (Meteor Client) - Minecraft 1.21.11

Moduly (kategoria "Vexy"):
- Vexy Chunk Finder - oznacza chunki z duza liczba block entities
- Vexy Debug - info debugowe na czacie
- Spawner Notifier - powiadomienia o spawnerach
- Vexy ESP - box ESP dla wybranych encji
- Vexy Storage ESP - skrzynki, beczki, shulkery, enderchesty
- Vexy Player Alert - alert o graczach w poblizu
- Vexy Auto Command - cykliczne wysylanie komendy
- Vexy Auto Totem - totem w offhandzie
- Vexy Rain Notifier - powiadomienie o deszczu/burzy
- Vexy Coord Snapper - kopiuje koordy do schowka
- Vexy Tab Detector - obserwuje wejscia/wyjscia graczy z TAB-a
- Vexy Chest Stealer - szybko oprozznia kontenery
- Vexy Block ESP - ESP na wybrane bloki (dripstone, kelp, ametyst, pistony...)
- Vexy Hole ESP - szyby 1x1
- Vexy Death Coords - koordy miejsca smierci
- Vexy Item Dropper - wyrzuca wybrane przedmioty

Uwaga: Meteor na 1.21.11 uzywa oficjalnych mapowan Mojanga (Yarn nie dziala z jego snapshotem).

Build:
1. Skopiuj `gradle/` + `gradlew` + `gradlew.bat` z https://github.com/MeteorDevelopment/meteor-addon-template
   (albo `gradle wrapper`). Wrapper musi byc nowy (Loom 1.14 wymaga Gradle 8.14+ / 9.x).
2. Jesli build sie wywala na wersji Loom/loadera, ustaw takie jak w template.
3. `./gradlew build` -> jar w `build/libs/`
4. Wrzuc jar do `mods/` razem z Meteor Client 1.21.11.

## Gotowy jar bez komputera z Gradle (GitHub Actions)
1. Utworz repo na GitHubie i wrzuc do niego cala zawartosc tego folderu (razem z `.github/`).
2. Wejdz w zakladke Actions -> "Build Vexy Addon" (odpali sie sam po pushu albo kliknij Run workflow).
3. Po zakonczeniu pobierz artefakt `vexy-addon` -> w srodku jest jar (nie `-sources`).
4. Jar do `mods/` razem z Fabric Loader, Fabric API i Meteor Client 1.21.11.
Workflow uzywa Gradle 8.14, wiec nie potrzebujesz gradle wrappera.
